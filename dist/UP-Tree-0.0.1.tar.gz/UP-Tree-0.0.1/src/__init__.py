from UPTree import UPTree


upTree, headerTable, trans_1 = UPTree(
    'D:\mithil ghinaiya\data_proj_1.txt', 'D:\mithil ghinaiya\profit1.txt')


# upTree.disp()
# print(headerTable)
# print(trans_1)
